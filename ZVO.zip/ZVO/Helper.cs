﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZVO
{
    public class Helper
    {
        public static Model.DBStrahPOLYKOVEntities DB;

        
        public static Model.Agent Agent;
    }
}

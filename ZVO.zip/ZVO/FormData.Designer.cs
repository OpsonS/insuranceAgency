﻿namespace ZVO
{
    partial class FormData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelName = new System.Windows.Forms.Label();
            this.labelPhone = new System.Windows.Forms.Label();
            this.labelPass = new System.Windows.Forms.Label();
            this.labelType = new System.Windows.Forms.Label();
            this.labelPeriod = new System.Windows.Forms.Label();
            this.labelCost = new System.Windows.Forms.Label();
            this.textName = new System.Windows.Forms.TextBox();
            this.textPhone = new System.Windows.Forms.TextBox();
            this.textPass = new System.Windows.Forms.TextBox();
            this.textType = new System.Windows.Forms.TextBox();
            this.textDate = new System.Windows.Forms.TextBox();
            this.textCost = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Location = new System.Drawing.Point(72, 68);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(43, 13);
            this.labelName.TabIndex = 0;
            this.labelName.Text = "Ф.И.О.";
            this.labelName.Click += new System.EventHandler(this.label1_Click);
            // 
            // labelPhone
            // 
            this.labelPhone.AutoSize = true;
            this.labelPhone.Location = new System.Drawing.Point(72, 91);
            this.labelPhone.Name = "labelPhone";
            this.labelPhone.Size = new System.Drawing.Size(93, 13);
            this.labelPhone.TabIndex = 1;
            this.labelPhone.Text = "Номер телефона";
            // 
            // labelPass
            // 
            this.labelPass.AutoSize = true;
            this.labelPass.Location = new System.Drawing.Point(72, 117);
            this.labelPass.Name = "labelPass";
            this.labelPass.Size = new System.Drawing.Size(91, 13);
            this.labelPass.TabIndex = 2;
            this.labelPass.Text = "Номер паспорта";
            // 
            // labelType
            // 
            this.labelType.AutoSize = true;
            this.labelType.Location = new System.Drawing.Point(72, 238);
            this.labelType.Name = "labelType";
            this.labelType.Size = new System.Drawing.Size(67, 13);
            this.labelType.TabIndex = 3;
            this.labelType.Text = "Тип Полиса";
            this.labelType.UseMnemonic = false;
            // 
            // labelPeriod
            // 
            this.labelPeriod.AutoSize = true;
            this.labelPeriod.Location = new System.Drawing.Point(72, 264);
            this.labelPeriod.Name = "labelPeriod";
            this.labelPeriod.Size = new System.Drawing.Size(85, 13);
            this.labelPeriod.TabIndex = 4;
            this.labelPeriod.Text = "Срок Действия";
            // 
            // labelCost
            // 
            this.labelCost.AutoSize = true;
            this.labelCost.Location = new System.Drawing.Point(72, 286);
            this.labelCost.Name = "labelCost";
            this.labelCost.Size = new System.Drawing.Size(74, 13);
            this.labelCost.TabIndex = 5;
            this.labelCost.Text = "Цена Полиса";
            // 
            // textName
            // 
            this.textName.Location = new System.Drawing.Point(174, 68);
            this.textName.Name = "textName";
            this.textName.Size = new System.Drawing.Size(100, 20);
            this.textName.TabIndex = 6;
            // 
            // textPhone
            // 
            this.textPhone.Location = new System.Drawing.Point(174, 95);
            this.textPhone.Name = "textPhone";
            this.textPhone.Size = new System.Drawing.Size(100, 20);
            this.textPhone.TabIndex = 7;
            // 
            // textPass
            // 
            this.textPass.Location = new System.Drawing.Point(174, 122);
            this.textPass.Name = "textPass";
            this.textPass.Size = new System.Drawing.Size(100, 20);
            this.textPass.TabIndex = 8;
            // 
            // textType
            // 
            this.textType.Location = new System.Drawing.Point(174, 238);
            this.textType.Name = "textType";
            this.textType.Size = new System.Drawing.Size(100, 20);
            this.textType.TabIndex = 9;
            // 
            // textDate
            // 
            this.textDate.Location = new System.Drawing.Point(174, 265);
            this.textDate.Name = "textDate";
            this.textDate.Size = new System.Drawing.Size(100, 20);
            this.textDate.TabIndex = 10;
            // 
            // textCost
            // 
            this.textCost.Location = new System.Drawing.Point(174, 292);
            this.textCost.Name = "textCost";
            this.textCost.Size = new System.Drawing.Size(100, 20);
            this.textCost.TabIndex = 11;
            // 
            // FormData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textCost);
            this.Controls.Add(this.textDate);
            this.Controls.Add(this.textType);
            this.Controls.Add(this.textPass);
            this.Controls.Add(this.textPhone);
            this.Controls.Add(this.textName);
            this.Controls.Add(this.labelCost);
            this.Controls.Add(this.labelPeriod);
            this.Controls.Add(this.labelType);
            this.Controls.Add(this.labelPass);
            this.Controls.Add(this.labelPhone);
            this.Controls.Add(this.labelName);
            this.Name = "FormData";
            this.Text = "FormData";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.Label labelPhone;
        private System.Windows.Forms.Label labelPass;
        private System.Windows.Forms.Label labelType;
        private System.Windows.Forms.Label labelPeriod;
        private System.Windows.Forms.Label labelCost;
        private System.Windows.Forms.TextBox textName;
        private System.Windows.Forms.TextBox textPhone;
        private System.Windows.Forms.TextBox textPass;
        private System.Windows.Forms.TextBox textType;
        private System.Windows.Forms.TextBox textDate;
        private System.Windows.Forms.TextBox textCost;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZVO.Model;

namespace ZVO
{
    public partial class Table : Form
    {
        public Table()
        {
            InitializeComponent();
        }

        private void Table_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
            Load_T();
        }
        private void Load_T()
        {
            List<Model.Police> polices = Helper.DB.Police.ToList();

            if (Search1.Text != "")
            {
                //List<Model.Client> clients = clients.Where(c => c.FIO == Search1.Text).ToList();
                polices = polices.Where(c => c.Client.FIO.Contains(Search1.Text)).ToList();
            }


            this.dataGridViewPolice.Rows.Clear();
            int i = 0;
            foreach (var police in polices)
            {
                if (comboBox1.Items.Contains(police.TypePolice.namePolice)) { } else { comboBox1.Items.Insert(i+1, police.TypePolice.namePolice); } 
                this.dataGridViewPolice.Rows.Add();
                this.dataGridViewPolice.Rows[i].Cells[0].Value = police.Client.FIO;
                this.dataGridViewPolice.Rows[i].Cells[1].Value = police.TypePolice.namePolice;
                this.dataGridViewPolice.Rows[i].Cells[2].Value = police.costPolicy;
                this.dataGridViewPolice.Rows[i].Cells[3].Value = police.dateReg;
                this.dataGridViewPolice.Rows[i].Cells[4].Value = police.TypePolice.period;
                i++;
            }
            //name = Helper.DB.Client.ToList();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Load_T();
        }

        private void ShowFlat()
        {
            //List<Model.Client> clients = Helper.DB.Client.ToList();
            //if (Search1.Text != "")
            //{
            //    //List<Model.Client> clients = clients.Where(c => c.FIO == Search1.Text).ToList();
            //     clients = clients.Where(c => c.FIO.Contains(Search1.Text)).ToList();
            //}
        }

        private void Search1_TextChanged(object sender, EventArgs e)
        {
            Load_T();
        }

        private void dataGridViewPolice_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

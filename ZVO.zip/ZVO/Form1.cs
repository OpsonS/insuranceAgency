﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Infrastructure;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZVO.Model;

namespace ZVO
{
    public partial class Form1 : Form
    {
        char n;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            loginBox.Text = "Введите логин";
            loginBox.ForeColor = Color.Gray;
            passwordBox.Text = "Введите пароль";
            passwordBox.ForeColor = Color.Gray;
            n = passwordBox.PasswordChar;
            try
            {
                Helper.DB = new Model.DBStrahPOLYKOVEntities();
                MessageBox.Show("Успешное покдлючение к БД", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show("Ошибка подключения");
                Environment.Exit(-1);
            }
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void loginBox_Enter(object sender, EventArgs e)
        {
                if (loginBox.Text == "Введите логин")
                {
                    loginBox.Clear();
                    loginBox.ForeColor = Color.Black;
                }    
        }

        private void loginBox_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonEnter_Click(object sender, EventArgs e)
        {
            string login = loginBox.Text;
            string password = passwordBox.Text;
            Helper.Agent = null;
            List<Model.Agent> Agents = Helper.DB.Agent.ToList();
            List<Model.Agent> AgentLogPass = Agents.Where(c => c.login == login && c.password == password).ToList();

            Helper.Agent = AgentLogPass.FirstOrDefault();
            if (Helper.Agent != null)
            {
                MessageBox.Show("Пользователь найден");
            }
            else
            {
                MessageBox.Show("Не найден");
            }
        }

        private void buttonTable_Click(object sender, EventArgs e)
        {
            Table table = new Table();
            this.Hide();
            table.ShowDialog();
            this.Show();
        }

        private void loginBox_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(loginBox.Text))
            {
                loginBox.Text = "Введите логин";
                loginBox.ForeColor = Color.Gray;
            }
        }
        private void passwordBox_Enter(object sender, EventArgs e)
        {
            if (passwordBox.Text == "Введите пароль")
            {
                passwordBox.PasswordChar = '*';
                passwordBox.Clear();
                passwordBox.ForeColor = Color.Black;
            }
        }
        private void passwordBox_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(passwordBox.Text))
            {
                passwordBox.PasswordChar = n;
                passwordBox.Text = "Введите пароль";
                passwordBox.ForeColor = Color.Gray;
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}

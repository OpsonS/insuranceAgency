﻿namespace ZVO
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonOsago = new System.Windows.Forms.Button();
            this.buttonContract = new System.Windows.Forms.Button();
            this.buttonWork = new System.Windows.Forms.Button();
            this.buttonClaim = new System.Windows.Forms.Button();
            this.buttonProfile = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonOsago
            // 
            this.buttonOsago.Location = new System.Drawing.Point(54, 72);
            this.buttonOsago.Name = "buttonOsago";
            this.buttonOsago.Size = new System.Drawing.Size(145, 43);
            this.buttonOsago.TabIndex = 0;
            this.buttonOsago.Text = "Страховые полюса";
            this.buttonOsago.UseVisualStyleBackColor = true;
            // 
            // buttonContract
            // 
            this.buttonContract.Location = new System.Drawing.Point(401, 72);
            this.buttonContract.Name = "buttonContract";
            this.buttonContract.Size = new System.Drawing.Size(138, 42);
            this.buttonContract.TabIndex = 1;
            this.buttonContract.Text = "Договор страхования";
            this.buttonContract.UseVisualStyleBackColor = true;
            // 
            // buttonWork
            // 
            this.buttonWork.Location = new System.Drawing.Point(557, 72);
            this.buttonWork.Name = "buttonWork";
            this.buttonWork.Size = new System.Drawing.Size(147, 42);
            this.buttonWork.TabIndex = 2;
            this.buttonWork.Text = "Работа с клиентами";
            this.buttonWork.UseVisualStyleBackColor = true;
            // 
            // buttonClaim
            // 
            this.buttonClaim.Location = new System.Drawing.Point(222, 72);
            this.buttonClaim.Name = "buttonClaim";
            this.buttonClaim.Size = new System.Drawing.Size(147, 42);
            this.buttonClaim.TabIndex = 3;
            this.buttonClaim.Text = "Страховые заявления";
            this.buttonClaim.UseVisualStyleBackColor = true;
            // 
            // buttonProfile
            // 
            this.buttonProfile.Location = new System.Drawing.Point(12, 12);
            this.buttonProfile.Name = "buttonProfile";
            this.buttonProfile.Size = new System.Drawing.Size(49, 44);
            this.buttonProfile.TabIndex = 4;
            this.buttonProfile.UseVisualStyleBackColor = true;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonProfile);
            this.Controls.Add(this.buttonClaim);
            this.Controls.Add(this.buttonWork);
            this.Controls.Add(this.buttonContract);
            this.Controls.Add(this.buttonOsago);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonOsago;
        private System.Windows.Forms.Button buttonContract;
        private System.Windows.Forms.Button buttonWork;
        private System.Windows.Forms.Button buttonClaim;
        private System.Windows.Forms.Button buttonProfile;
    }
}